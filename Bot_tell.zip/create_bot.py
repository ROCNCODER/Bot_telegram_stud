from aiogram import Bot
from aiogram.dispatcher import Dispatcher



TOK="5338219426:AAGWygEVie8iBPMYFqXkvG9yTgxC5oLfABo"
bot = Bot(token=TOK)
dp=Dispatcher(bot)
